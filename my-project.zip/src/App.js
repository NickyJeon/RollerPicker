import React from 'react';
import RollerPicker from './RollerPicker';

function App() {
  return (
    <div>
      <h1>My App</h1>
      <RollerPicker />
    </div>
  );
}

export default App;

