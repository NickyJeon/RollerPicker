import { getCLS, getFID, getLCP, getFCP, getTTFB } from 'web-vitals';
const { getCLS, getFID, getLCP, getFCP, getTTFB } = require('web-vitals');

